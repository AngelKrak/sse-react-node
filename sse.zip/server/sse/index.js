const SSE = require("express-sse");

const sse = new SSE(["test data"]);

module.exports = sse;
