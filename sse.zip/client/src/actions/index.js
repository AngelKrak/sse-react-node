export const GET_POSTS = "GET_POSTS";
export const GET_POST_STREAM = "GET_POST_STREAM";
export const POST_REACTION = "POST_REACTION";
